#ifndef TOTAL_ATRIBUTOS_H
#define TOTAL_ATRIBUTOS_H

#include "att.h"

int total_atributos(att* schema);

#endif // TOTAL_ATRIBUTOS_H