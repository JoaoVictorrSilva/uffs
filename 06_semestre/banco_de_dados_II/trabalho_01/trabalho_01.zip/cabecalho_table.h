#ifndef CABECALHO_TABLE_H
#define CABECALHO_TABLE_H

#include "att.h"

int cabecalho_table(att* schema);

#endif // CABECALHO_TABLE_H