import random
import os

class JogoCobrinha:
    def __init__(self, largura, altura):
        self.largura = largura
        self.altura = altura
        self.cobra = [(largura // 2, altura // 2)]  
        self.direcao = None
        self.macas = self.gerar_macas()
        self.pontos = 0

    def gerar_macas(self):
        while True:
            x = random.randint(0, self.largura - 1)
            y = random.randint(0, self.altura - 1)
            if (x, y) not in self.cobra:
                return x, y

    def imprimir_tabuleiro(self):
        os.system('cls' if os.name == 'nt' else 'clear')  

        tabuleiro = [[' ' for _ in range(self.largura + 2)] for _ in range(self.altura + 2)]

        
        for x in range(self.largura):
            tabuleiro[0][x + 1] = str('-')
            tabuleiro[-1][x + 1] = str('-')

        for y in range(self.altura):
            tabuleiro[y + 1][0] = str('|')
            tabuleiro[y + 1][-1] = str('|')

        tabuleiro[0][0] = '+'
        tabuleiro[0][-1] = '+'
        tabuleiro[-1][0] = '+'
        tabuleiro[-1][-1] = '+'

        for x, y in self.cobra:
            tabuleiro[y + 1][x + 1] = '*'

        ax, ay = self.macas
        tabuleiro[ay + 1][ax + 1] = 'M'

        for linha in tabuleiro:
            print(''.join(linha))

    def mover_cobra(self, direcao):
        x, y = self.cobra[0]
        dx, dy = direcao

        nova_cabeca = (x + dx, y + dy)

        if nova_cabeca in self.cobra or not (0 <= nova_cabeca[0] < self.largura) or not (0 <= nova_cabeca[1] < self.altura):
            print("Fim de Jogo! Pontuação:", self.pontos)
            return False

        self.cobra.insert(0, nova_cabeca)

        if nova_cabeca == self.macas:
            self.pontos += 1
            self.macas = self.gerar_macas()
        else:
            self.cobra.pop()

        return True

    def iniciar(self):
        self.direcao = None
        while True:
            self.imprimir_tabuleiro()

            print("Digite W para cima, S para baixo, A para esquerda, D para direita:")
                
            escolha = input().strip().upper()

            if self.direcao is None:
                if escolha == 'W':
                    self.direcao = (0, -1)
                elif escolha == 'S':
                    self.direcao = (0, 1)
                elif escolha == 'A':
                    self.direcao = (-1, 0)
                elif escolha == 'D':
                    self.direcao = (1, 0)
            else:
                if escolha == 'W':
                    if not self.mover_cobra((0, -1)):
                        break
                elif escolha == 'S':
                    if not self.mover_cobra((0, 1)):
                        break
                elif escolha == 'A':
                    if not self.mover_cobra((-1, 0)):
                        break
                elif escolha == 'D':
                    if not self.mover_cobra((1, 0)):
                        break
                else:
                    print("Escolha uma direção válida.")

            print()

jogo = JogoCobrinha(20, 10)
jogo.iniciar()
