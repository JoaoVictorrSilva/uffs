#ifndef LINHAS_H
#define LINHAS_H

#include <stdio.h>

void linhas(int numero_atributos, int* largura);

#endif // LINHAS_H