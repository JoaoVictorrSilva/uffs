#include "Aresta.h"
#include "Grafo.h"
#include <iostream>

using namespace std;

int main() {
    try {
        Grafo grafo(5);

        grafo.imprime();

        Aresta e(3, 4);
        grafo.insere_aresta(e);

        grafo.insere_aresta(Aresta(4, 2));
        grafo.imprime();
    }
    catch (const exception &e) {
        cerr << "exception: " << e.what() << "\n";
    }

    return 0;
}
