#ifndef INSERT_TABLE_H
#define INSERT_TABLE_H

#include "table.h"
#include "att.h"

int insert_table(table tabela, att* schema);

#endif // INSERT_TABLE_H