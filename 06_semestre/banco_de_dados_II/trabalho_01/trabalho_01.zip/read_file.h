#ifndef READ_FILE_H
#define READ_FILE_H

#include "table.h"
#include "att.h"

int read_file(char busca_nome_logico[20]);

#endif // READ_FILE_H