#ifndef BUSCA_TABLE_H
#define BUSCA_TABLE_H

#include "table.h"

table busca_table(char busca_nome_logico[20]);

#endif // BUSCA_TABLE_H