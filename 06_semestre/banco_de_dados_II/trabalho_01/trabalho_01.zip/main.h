#ifndef MAIN_H
#define MAIN_H

int read_file(char busca_nome_logico[20]);

#endif // MAIN_H