#ifndef TOTAL_LARGURA_MAXIMA_H
#define TOTAL_LARGURA_MAXIMA_H

#include "att.h"

int* total_largura_maxima(att* schema, int numero_atributos);

#endif // TOTAL_LARGURA_MAXIMA_H
