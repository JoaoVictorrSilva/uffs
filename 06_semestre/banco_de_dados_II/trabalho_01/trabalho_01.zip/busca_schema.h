#ifndef BUSCA_SCHEMA_H
#define BUSCA_SCHEMA_H

#include "table.h"
#include "att.h"

att* busca_schema(table tabela);

#endif // BUSCA_SCHEMA_H